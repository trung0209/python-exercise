from Q1.Animal import Animal

class Hippo(Animal):

    def makeNoise(self):
        print("Hippo noise")

    def eat(self):
        print("Hippo eat")
