from Q1.Feline import Feline

class Tiger(Feline):

    def makeNoise(self):
        print("Tiger Noise")

    def eat(self):
        print("Tiger eat")