from Q1.Canine import Canine

class Wolf(Canine):

    def makeNoise(self):
        print("Wolf Noise")

    def eat(self):
        print("Wolf eat")