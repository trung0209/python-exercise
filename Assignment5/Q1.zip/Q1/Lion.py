from Q1.Feline import Feline

class Lion(Feline):

    def makeNoise(self):
        print("Lion Noise")

    def eat(self):
        print("Lion eat")
