from Q1.Animal import Animal

class Canine(Animal):
    def roam(self):
        print("Canine roam method")