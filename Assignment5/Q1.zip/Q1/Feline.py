from Q1.Animal import Animal

class Feline(Animal):

    def roam(self):
        print("Feline roam method")
